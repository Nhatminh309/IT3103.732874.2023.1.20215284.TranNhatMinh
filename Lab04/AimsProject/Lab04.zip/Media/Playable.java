package Lab04.AimsProject.Media;

public interface Playable {
    public void play();
}
