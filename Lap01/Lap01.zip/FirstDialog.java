import javax.swing.JOptionPane;  // Import thư viện để sử dụng JOptionPane

public class FirstDialog {
    public static void main(String[] args) {
        // Hiển thị hộp thoại thông báo chào mừng
        JOptionPane.showMessageDialog(null, "Hello world! How old are you?");

        System.exit(0);  // Kết thúc chương trình
    }
}
