public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Tran Nhat Minh - 2003"); // In ra dòng này với tên và năm sinh của bạn
        System.out.println("Xin chao \n cac ban!"); // In ra "Xin chào" trên một dòng và "các bạn!" trên dòng mới
        System.out.println("Hello \t world!"); // In ra "Hello" sau đó có một tab và tiếp theo là "world!"
    }
}
